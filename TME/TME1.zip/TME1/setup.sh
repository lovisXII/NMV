#! /bin/bash

apt install qemu-system-x86 mtools xorriso
